//var cheminsManager = new CheminsManager(levels);
var app = new Application(levels);

var balls = [];
var playfieldWidth, playfieldHeight;
var gameRefresh;
var ballSize;
var curLevel;
var bricks = []; 
var racket;
var bInit;
var cheminfinale = [];
var cheminBricks = [];
var t = [];

$(document).ready(init);

function init()
{
    curLevel = 0;

    playfieldWidth = $('.playfield').width();
    playfieldHeight = $('.playfield').height();
	drawPlayfield();
    drawBalls();
	bInit = {l: $('.brick').width()/2, t: $('.brick').height()/2};

	app.Lancer();
	brickChemin();

	gameRefresh = setInterval(drawBalls, 10);



	



	alert(app.cheminsManager.cheminfin);


	//alert(cheminf)

}

function drawPlayfield()
{
	levels[curLevel].forEach(function (e, i)
                             {
								  var line = $('<div class="brickLine"></div>');
			          				  e.forEach (function (f, j)
			                                       {
			                                         bricks.push ({
			                                                   		id: i + '-' + j, 
			                                      		    	 	top: i * 58,										     
			                                      		     		left: j * 62
			                                                     }) ;
			                                         line.append('<div class="brick ' + f + 'Brick" data-id="' + i + '-' + j + '"></div>');
			   						   });
			    			         $('.playfield').prepend(line);
					         }
 				      );
	bricks.forEach(function (e, i)
					  {
					     $('.brick[data-id="' + e.id + '"]')
		                          .animate(
								{
								   top: e.top + 'px'
								},
								500
							     );
						}
					);
	bricks.forEach(function (e, i)
					  {
						$('.brick[data-id="' + e.id + '"]')
					          .animate(
								{
								    left: e.left + 'px'
								},
								1000,
								function ()
								{
								   	if (i == bricks.length - 1)
								    {
			                           	addBall();
									}
							     });
				   });
}

function addBall()
{
	if( balls.length < 10)
	{
		$('.playfield').prepend('<div class="ball" data-id="' + balls.length + '"></div>');
        ballSize = $('.ball:first').width();
		balls.push 	(
						{
							/*id: balls.length, 
							left: Math.random() * (playfieldWidth - ballSize), 
							top: Math.random() * (playfieldHeight - ballSize), 
							hSpeed: 2, 
							vSpeed: 2*/
							id: balls.length,
							left: cheminBricks[0].left + 2, 
							top: cheminBricks[0].top + 2, 
							hSpeed: 2, 
							vSpeed: 2,
							s : {i:0,j:0}

						}
					);

					t = cheminBricks.splice(0,1);

	}
}

function drawBalls()
{

	balls.forEach (function (e)
                   {
						
 	 	       //forMoveball(e);
	   });
	   
}






function brickChemin(){
	cheminfinale = app.cheminsManager.cheminfin.split("-");
	var tab =[];
	cheminfinale.forEach(
		function(e){
			var s = e.split(';');
			var ss = [Number(s[0][1]), Number(s[1])];
			tab.push(ss);

	});
	tab.forEach(function(c){
		var id = c[0]+"-"+c[1];
		bricks.forEach(function(bc){
		if (id == bc.id){
			cheminBricks.push(bc);
		}
	});
	});
}


function forMoveball(b){
	//c pour case et b pour ball

	cheminBricks.forEach(function(c){
		
		step(c,b);
	})
}

function step(c,b){
	var tab = c.id.split('-');
	tab = [Number(tab[0]), Number(tab[1])];
	if ((tab[0]==b.s.i) && (tab[1]==b.s.j)){     
		
	 }

	 if(tab[0] == b.s.i){
		if(tab[1] > b.s.j){
			el = $('.brick[data-id="' + c.id + '"]').position();
			for(var i=0; i<= el.left/2; i=i+b.hSpeed){
				b.left += b.hSpeed;
				$('.ball[data-id="' + b.id + '"]')
					.css (
						{
							left: b.left + 'px',
							
						}
					);

				}
				b.s.j = tab[1];

		}

		else{

			el = $('.brick[data-id="' + c.id + '"]').position();
			for(var i=0; i <= el.left/2; i=i+b.hSpeed){
				b.left -= b.hSpeed;
				$('.ball[data-id="' + b.id + '"]')
					.css (
						{
							left: b.left + 'px',
							
						}
					);


				}
				b.s.j = tab[1];


		}

	}

	if(tab[1] == b.s.j){
		if(tab[0] > b.s.i){
			el = $('.brick[data-id="' + c.id + '"]').position();
			for(var i=0; i< el.top/2; i=i+b.vSpeed){
				b.top += b.vSpeed;
				$('.ball[data-id="' + b.id + '"]')
					.css (
						{
							top: b.top + 'px',
							
						}
					);

				}
				b.s.i = tab[0];


		}

		else{

			el = $('.brick[data-id="' + c.id + '"]').position();
			for(var i=0; i<= el.top/2; i=i+b.hSpeed){
				b.top -= b.hSpeed;
				$('.ball[data-id="' + b.id + '"]')
					.css (
						{
							top: b.top + 'px',
							
						}
					);

				}

				b.s.i = tab[0];
		}
	}

	
	

}


CheminsManager
    .prototype
    .RechercheEnProfondeur = function  (graphe) {
        // Constructeur

        
        // Méthode de résolution
            // Création de la liste des noeuds non visités et de la pile
            var noeudsNonVisites =[];
            noeudsNonVisites = [].concat(graphe.ListeNoeuds());
            //alert("__graphe__"+graphe.tuiles);


            //alert(noeudsNonVisites);

            var noeudsAVisiter = [];
            noeudsAVisiter.push(graphe.noeudDepart);

            noeudsNonVisites.forEach(function(e,i){
                
                e.forEach(function(c,j){

                    if ((c.ligne == graphe.noeudDepart.ligne) && (c.colonne == graphe.noeudDepart.colonne)){
                        delete noeudsNonVisites[i][j];
                    }

                });
            });
           //console.log("1111111"+noeudsNonVisites);

            //alert(noeudsNonVisites);


            // Initialisation de la sortie
            noeudSortie = graphe.noeudArrivee;
            sortieTrouvee = false;
            
            // Boucle principale
            while(!sortieTrouvee && noeudsAVisiter.length != 0) {

                var noeudCourant = noeudsAVisiter.pop();

                if ((noeudCourant.ligne == noeudSortie.ligne) && (noeudCourant.colonne == noeudSortie.colonne)) {
                    // On a fini l'algorithme
                    var sortieTrouvee = true;
                }
                else {
                    graphe.source = noeudCourant;
                    console.log("source->"+noeudCourant)
                    var ns = [].concat(graphe.ListeNoeudAdjacents());
                    console.log("voisins"+ns);
                    console.log("noeuds a visiter"+noeudsAVisiter);
                    //alert("suivant:___")

                    //alert("adjecent"+ns);

                    // On ajoute les voisins non encore visités
                    ns.forEach(n => {noeudsNonVisites.forEach(
                        function(e,i){
                                e.forEach(function(c,j){
                    
                            if ((c.ligne == n.ligne) && (c.colonne == n.colonne)){

                                delete noeudsNonVisites[i][j];

                        //alert(noeudsNonVisites);
                        //alert("__graphe__"+graphe.tuiles);
                                n.precurseur = noeudCourant;
                                n.distanceDuDepart = noeudCourant.distanceDuDepart + graphe.Cout(noeudCourant, n);
                                noeudsAVisiter.push(n);

                    }

                });
            });             
            

                            //console.log("2222222"+noeudsNonVisites);

                            
                        
                    });
                }
            }
        
    }


	CheminsManager
.prototype
.ListeNoeudAdjacents = function (){
    var source = this.source;
    var listeNoeudsSortants = [];
    var ligne = source.ligne;
    var colonne = source.colonne;


    
    this.Carte(levels, 0, 0, 9, 9);
    //voisin de droite
    
    if (colonne - 1 >= 0 && this.tuiles[ligne][colonne - 1].Accessible()){
        listeNoeudsSortants.push(this.tuiles[ligne][colonne - 1]);
        //alert(listeNoeudsSortants);

    }

    // Voisin de gauche
    if (colonne + 1 < this.nbColonnes && this.tuiles[ligne][colonne+1].Accessible()) {
        listeNoeudsSortants.push(this.tuiles[ligne][colonne+1]);
    }
    
    // Voisin du haut
    if (ligne - 1 >= 0 && this.tuiles[ligne-1][colonne].Accessible()) {
        listeNoeudsSortants.push(this.tuiles[ligne-1][colonne]);
    }
    
    // Voisin du bas
    if (ligne + 1 < this.nbLignes && this.tuiles[ligne+1][colonne].Accessible()) {
        listeNoeudsSortants.push(this.tuiles[ligne+1][colonne]);
    }
    //alert(listeNoeudsSortants);
    return listeNoeudsSortants;
    

}




////////////////////////////:jeu avant

//var cheminsManager = new CheminsManager(levels);
var app = new Application(levels);

var balls = [];
var playfieldWidth, playfieldHeight;
var gameRefresh;
var ballSize;
var curLevel;
var bricks = []; 
var racket;
var bInit;
var algo = ['Profondeur','Largeur','Bellman-Ford'];

var cheminfinale = new Array(algo.length);
var cheminBricks = [];
var t = [];

var algo = ['Profondeur','Largeur','Bellman-Ford'];
		

$(document).ready(init);

function init()
{
    curLevel = 0;
    playfieldWidth = $('.playfield').width();
    playfieldHeight = $('.playfield').height();
	drawPlayfield();
    drawBalls();
	bInit = {l: $('.brick').width()/2, t: $('.brick').height()/2};
	gameRefresh = setInterval(drawBalls, 10);

	app.Lancer('Bellman-Ford');
	brickChemin();


	alert("Parcours de chemin intelligent");
	console.log("le chemin trouvé est :"+app.cheminsManager.cheminfin);
	//alert(cheminf)
}

function drawPlayfield()
{
	levels[curLevel].forEach(function (e, i)
                             {
								  var line = $('<div class="brickLine"></div>');
			          				  e.forEach (function (f, j)
			                                       {
			                                         bricks.push ({
			                                                   		id: i + '-' + j, 
			                                      		    	 	top: i * 58,										     
			                                      		     		left: j * 62
			                                                     }) ;
			                                         line.append('<div class="brick ' + f + 'Brick" data-id="' + i + '-' + j + '"></div>');
			   						   });
			    			         $('.playfield').prepend(line);
					         }
 				      );
	bricks.forEach(function (e, i)
					  {
					     $('.brick[data-id="' + e.id + '"]')
		                          .animate(
								{
								   top: e.top + 'px'
								},
								500
							     );
						}
					);
	bricks.forEach(function (e, i)
					  {
						$('.brick[data-id="' + e.id + '"]')
					          .animate(
								{
								    left: e.left + 'px'
								},
								1000,
								function ()
								{
								   	if (i == bricks.length - 1)
								    {
			                           	addBall();
									}
							     });
				   });
}

function initBall()
{
	if( balls.length < 10)
	{
		$('.playfield').prepend('<div class="ball" data-id="' + balls.length + '"></div>');
        //ballSize = $('.ball:first').width();
		for (i=0; i < 3 ; i++){
			balls.push 	(
				{
					/*id: balls.length, 
					left: Math.random() * (playfieldWidth - ballSize), 
					top: Math.random() * (playfieldHeight - ballSize), 
					hSpeed: 2, 
					vSpeed: 2*/
					id: balls.length,
					left: cheminBricks[0].left + bInit.l/2, 
					top: cheminBricks[0].top + bInit.t/2, 
					hSpeed: 2, 
					vSpeed: 2,
					s : {i:0,j:0}

				}
			);
		}
			

	
		

					//t = cheminBricks.splice(0,1);
	}
}



function drawBalls()
{

	balls.forEach (function (e)
            {

 	 	       forMoveball(e);
	   });
	   
}

function arretCourse(ef){
	var fin = cheminBricks[cheminBricks.length-1];
	id = ef.s.i+"-"+ef.s.j
	if(fin.id == id){
		clearInterval(gameRefresh);
		gameRefresh = undefined;
		


	}
}

function marquerchemin(b){
	

}


function brickChemin(){
	cheminfinale = app.cheminsManager.cheminfin.split("-");
	var tab =[];
	cheminfinale.forEach(
		function(e){
			var s = e.split(';');
			var ss = [Number(s[0][1]), Number(s[1])];
			tab.push(ss);

	});
	tab.forEach(function(c){
		var id = c[0]+"-"+c[1];
		bricks.forEach(function(bc){
		if (id == bc.id){
			cheminBricks.push(bc);
		}
	});
	});
}

function addBall(){
	initBall();
	balls
		.forEach 	(
			function (e)
                {
					$('.ball[data-id="' + e.id + '"]')
   					.css 	(
					{
						left: e.left + 'px',
						top: e.top + 'px'
					}
				);
                   			
		   				}
		   			);
	
}

function forMoveball(b){
	//c pour case et b pour ball

	cheminBricks.forEach(function(c){
		
		step(c,b);
		arretCourse(b);
	})
}

function step(c,b){
	var tab = c.id.split('-');
	var top1;
	var left1;
	tab = [Number(tab[0]), Number(tab[1])];
	/*if ((tab[0]==b.s.i) && (tab[1]==b.s.j)){     
		
	 }*/
	 

	 if(tab[0] == b.s.i){
		if(tab[1] > b.s.j){
			el = $('.brick[data-id="' + c.id + '"]').position();
			left1 = el.left + bInit.l/2;
			$('.ball[data-id="' + b.id + '"]')
				. animate(
					{
						left: left1 + 'px',
						
					},
					500
					 
				
					);
					b.s.j = tab[1];

				}
				else{

					el = $('.brick[data-id="' + c.id + '"]').position();
					left1 = el.left + bInit.l/2;

						$('.ball[data-id="' + b.id + '"]')
						. animate(
							{
								left: left1 + 'px',
								
							},
							500
							 
						);
						
							
		
		
						
						b.s.j = tab[1];
		
		
				}
				

		}

		


		if(tab[1] == b.s.j){
			if(tab[0] > b.s.i){
				el = $('.brick[data-id="' + c.id + '"]').position();
				top1 = el.top + bInit.t/2;

					$('.ball[data-id="' + b.id + '"]')
						. animate(
							{
								top: top1 + 'px',
								
							},
							500
							 
						);
	
					b.s.i = tab[0];
	
	
			}
	
			else{
	
				el = $('.brick[data-id="' + c.id + '"]').position();
				top1 = el.top + bInit.t/2;

					$('.ball[data-id="' + b.id + '"]')
						. animate(
							{
								top: top1 + 'px',
								
							},
							500
							 
						);
						

					}
	
					b.s.i = tab[0];
		}
	
	
	}

	