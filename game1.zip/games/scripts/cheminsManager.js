

function Tuile(_type, _ligne, _colonne){
    this.type = _type;
    this.ligne = _ligne;
    this.colonne = _colonne;
    this.precurseur = null;
    this.distanceDuDepart = Number.POSITIVE_INFINITY;
    this.distanceEstime;
    this.cheminfin = null;
    //this.CManager = new CheminsManager(levels);
}

Tuile
.prototype
.Accessible = function(){
    return (this.type =="c") || (this.type == "h") || (this.type == "p")
}

Tuile
.prototype
.Cout = function(){
    switch(this.type){
        case "c":
            return 1;
        case "p":
        case "h":
            return 2;
        default:
            return Number.POSITIVE_INFINITY;

    }
}

Tuile
.prototype
.toString = function(){
    return "["+ this.ligne + ";" + this.colonne + ";" + this.type + "]";
}

function Arc(_source, _cible, _cout) {
    this.source = _source;
    this.cible = _cible;
    this.cout = _cout;
}

function CheminsManager(cartes){
    this.carte1 = cartes;
    this.source = null;

    this.tuiles = null;
    this.noeudDepart = null;
    this.noeudArrivee = null;
    this.listeNoeuds = null;
    this.listeArcs = null;
    this.cartes = cartes;
    this.nbLignes = 0;
    this.nbColonnes = 0;


}

CheminsManager
.prototype
.charToType = function(charCarte){
    switch(charCarte){
        case "c":
            return 1;
        case "p":
        case "h":
            return 2;
        default:
            return Number.POSITIVE_INFINITY;

    }
}

CheminsManager
.prototype
.Carte = function(_carte1, _ligneDepart, _colonneDepart, _ligneArrivee,_colonneArrivee){
    var _carte = levels[0];
    this.nbLignes = _carte.length;
    this.nbColonnes = _carte[0].length;
    this.tuiles = new Array(this.nbLignes);
    for (var i=0; i < this.nbLignes; i++){
        this.tuiles[i] = new Array(this.nbColonnes);
        for(var j=0; j < this.nbColonnes; j++){
            var type =_carte[i][j]
            //var type = this.charToType(_carte[i][j]);
            this.tuiles[i][j] = new Tuile(type,i,j);
        }
    }
    this.noeudDepart = this.tuiles[_ligneDepart][_colonneDepart];
    this.noeudDepart.distanceDuDepart = this.noeudDepart.Cout()
    this.noeudArrivee = this.tuiles[_ligneArrivee][_colonneArrivee];
    this.ListeNoeuds();
    //temp = this.tuiles.slice();
    this.ListeArcs();

    

    


    
}

CheminsManager
.prototype
.ListeNoeuds = function (){
    if(this.listeNoeuds == null){
        this.listeNoeuds = [];
        for( var i=0; i < this.nbLignes; i++){
            this.listeNoeuds.push(this.tuiles[i])
        }
    }
    return this.listeNoeuds;
}




CheminsManager
.prototype
.NombreNoeuds = function () {
    return this.nbLignes * this.nbColonnes;
}

CheminsManager
.prototype
.ListeNoeudAdjacents1 = function (){
    var source = this.source;
    var listeNoeudsSortants = [];
    var ligne = source.ligne;
    var colonne = source.colonne;

    //var tuiletemp = [];
    //tuiletemp = this.tuiles;


    
    //this.Carte(levels, 0, 0, 9, 9);


    //voisin de droite
    
    if (colonne - 1 >= 0 && this.tuiles[ligne][colonne - 1].Accessible()){
        listeNoeudsSortants.push(this.tuiles[ligne][colonne - 1]);
        //alert(listeNoeudsSortants);

    }

    // Voisin de gauche
    if (colonne + 1 < this.nbColonnes && this.tuiles[ligne][colonne+1].Accessible()) {
        listeNoeudsSortants.push(this.tuiles[ligne][colonne+1]);
    }
    
    // Voisin du haut
    if (ligne - 1 >= 0 && this.tuiles[ligne-1][colonne].Accessible()) {
        listeNoeudsSortants.push(this.tuiles[ligne-1][colonne]);
    }
    
    // Voisin du bas
    if (ligne + 1 < this.nbLignes && this.tuiles[ligne+1][colonne].Accessible()) {
        listeNoeudsSortants.push(this.tuiles[ligne+1][colonne]);
    }
    //alert(listeNoeudsSortants);
    return listeNoeudsSortants;
    

}
    
CheminsManager
.prototype
.ListeArcsSortants = function(source) {
        var  listeArcsSortants = [];
        var ligne = source.ligne;
        var colonne = source.colonne;
        
        if (this.tuiles[ligne][colonne].Accessible()) {
            // Droite
            if (colonne - 1 >= 0 && this.tuiles[ligne][colonne-1].Accessible()) {
                listeArcsSortants.push(new Arc(this.tuiles[ligne][colonne], this.tuiles[ligne][colonne-1], this.tuiles[ligne][colonne-1].Cout()));
            }

            // Gauche
            if (colonne + 1 < this.nbColonnes && this.tuiles[ligne][colonne+1].Accessible()) {
                listeArcsSortants.push(new Arc(this.tuiles[ligne][colonne], this.tuiles[ligne][colonne+1], this.tuiles[ligne][colonne+1].Cout()));
            }

            // Haut
            if (ligne - 1 >= 0 && this.tuiles[ligne-1][colonne].Accessible()) {
                listeArcsSortants.push(new Arc(this.tuiles[ligne][colonne], this.tuiles[ligne-1][colonne], this.tuiles[ligne-1][colonne].Cout()));
            }

            // Bas
            if (ligne + 1 < this.nbLignes && this.tuiles[ligne+1][colonne].Accessible()) {
                listeArcsSortants.push(new Arc(this.tuiles[ligne][colonne], this.tuiles[ligne+1][colonne], this.tuiles[ligne+1][colonne].Cout()));
            }
        }
        return listeArcsSortants;
    }
    
CheminsManager
.prototype
.ListeArcs = function() {
        if(this.listeArcs == null) {
            this.listeArcs = new Array();
            
            // Parcours des noeuds
            for (var ligne = 0; ligne < this.nbLignes; ligne++) {
                for (var colonne = 0; colonne < this.nbColonnes; colonne++) {
                    var arcs = this.ListeArcsSortants(this.tuiles[ligne][colonne]);
                    if(arcs.length!=0){
                        this.listeArcs.push(arcs);
                    }
                    
                }
            }
        }
        return this.listeArcs;
    }
    
CheminsManager
.prototype
.Cout = function(depart,arrivee) {
        return arrivee.Cout();
    }

CheminsManager
.prototype
.ReconstruireChemin = function(cheminsManager) {
        // Initialisation
        var chemin = "";
        var noeudCourant = cheminsManager.noeudArrivee;
        //console.log(cheminsManager.noeudArrivee);
        var noeudPrecedent = cheminsManager.noeudArrivee.precurseur;
        
        // Boucle sur les noeuds du chemin
        while (noeudPrecedent != null) {
            chemin = "-" + noeudCourant.toString() + chemin;
            noeudCourant = noeudPrecedent;
            noeudPrecedent = noeudCourant.precurseur;
        }
        this.cheminfin = noeudCourant.toString() + chemin;
        return chemin;
    }

CheminsManager
.prototype
.CalculerDistancesEstimees = function() {
        for (var ligne = 0; ligne < nbLignes; ligne++) {
            for (var colonne = 0; colonne < nbColonnes; colonne++) {
                this.tuiles[ligne][colonne].distanceEstimee = Math.abs(this.noeudArrivee.ligne - ligne) + Math.abs(this.noeudArrivee.colonne - colonne);
            }
        }
    }

CheminsManager
.prototype
.Effacer = function() {
        // Effacer les listes
        this.listeNoeuds = null;
        this.listeArcs = null;
        
        // Effacer les distances et précurseurs
        for (var ligne = 0; ligne < nbLignes; ligne++) {
            for (var colonne = 0; colonne < nbColonnes; colonne++) {
                this.tuiles[ligne][colonne].distanceDuDepart = Number.POSITIVE_INFINITY;
                this.tuiles[ligne][colonne].precurseur = null;
            }
        }
        
        // Noeud initial
        this.noeudDepart.distanceDuDepart = this.noeudDepart.Cout();
    }

    CheminsManager
    .prototype
    .RechercheEnLargeur = function  (graphe) {
        // Constructeur

        
        // Méthode de résolution
            // Création de la liste des noeuds non visités et de la pile
            var noeudsNonVisites = graphe.ListeNoeuds();;
            //alert("__graphe__"+graphe.tuiles);


            //alert(noeudsNonVisites);

            var noeudsAVisiter = [];
            var noeudD =  new Tuile(graphe.noeudDepart.type, graphe.noeudDepart.ligne, graphe.noeudDepart.colonne); 
            noeudsAVisiter.push(noeudD);

            noeudsNonVisites = noeudsNonVisites.map(function(c){
                return c.filter(function(e){
                    return (!(c.ligne == graphe.noeudDepart.ligne && c.colonne == graphe.noeudDepart.colonne));
                });
            });
            
            
           ///console.log("---------"+noeudsNonVisites);

            //alert(noeudsNonVisites);


            // Initialisation de la sortie
            noeudSortie = graphe.noeudArrivee;
            sortieTrouvee = false;
            
            // Boucle principale
            while(!sortieTrouvee && noeudsAVisiter.length != 0) {

                var noeudCourant = noeudsAVisiter.shift();

                if ((noeudCourant.ligne == noeudSortie.ligne) && (noeudCourant.colonne == noeudSortie.colonne)) {
                    // On a fini l'algorithme
                    var sortieTrouvee = true;
                }
                else {
                    graphe.source = noeudCourant;
                    console.log("source->"+noeudCourant)
                    var ns = [].concat(graphe.ListeNoeudAdjacents1());
                    
                    console.log("voisins"+ns);
                    console.log("noeuds a visiter"+noeudsAVisiter);
                    //alert("suivant:___")

                    //alert("adjecent"+ns);

                    // On ajoute les voisins non encore visités
                    ns.forEach(n => {noeudsNonVisites.forEach(
                        function(e,i){
                                e.forEach(function(c,j){
                    
                            if ((c.ligne == n.ligne) && (c.colonne == n.colonne)){

                                noeudsNonVisites =  noeudsNonVisites.map(function(w){
                                    return w.filter(function(x){
                                        return (!(x.ligne == n.ligne && x.colonne == n.colonne));
                                    });
                                });

                        //alert(noeudsNonVisites);
                        //alert("__graphe__"+graphe.tuiles);
                                n.precurseur = noeudCourant;
                                n.distanceDuDepart = noeudCourant.distanceDuDepart + graphe.Cout(noeudCourant, n);
                                noeudsAVisiter.push(n);

                    }

                });
            });             
            

                            //console.log("2222222"+noeudsNonVisites);

                            
                        
                    });
                }
            }
        
    }


    CheminsManager
    .prototype
    .RechercheEnProfondeur = function  (graphe) {
        // Constructeur

        
        // Méthode de résolution
            // Méthode de résolution
            // Création de la liste des noeuds non visités et de la pile
            var noeudsNonVisites = graphe.ListeNoeuds();;
            //alert("__graphe__"+graphe.tuiles);


            //alert(noeudsNonVisites);

            var noeudsAVisiter = [];
            var noeudD =  new Tuile(graphe.noeudDepart.type, graphe.noeudDepart.ligne, graphe.noeudDepart.colonne); 
            noeudsAVisiter.push(noeudD);

            noeudsNonVisites = noeudsNonVisites.map(function(c){
                return c.filter(function(e){
                    return (!(c.ligne == graphe.noeudDepart.ligne && c.colonne == graphe.noeudDepart.colonne));
                });
            });

            
           //console.log("1111111"+noeudsNonVisites);

            //alert(noeudsNonVisites);


            // Initialisation de la sortie
            noeudSortie = graphe.noeudArrivee;
            sortieTrouvee = false;
            
            // Boucle principale
            while(!sortieTrouvee && noeudsAVisiter.length != 0) {

                var noeudCourant = noeudsAVisiter.pop();

                if ((noeudCourant.ligne == noeudSortie.ligne) && (noeudCourant.colonne == noeudSortie.colonne)) {
                    // On a fini l'algorithme
                    var sortieTrouvee = true;
                }
                else {
                    graphe.source = noeudCourant;
                    console.log("source->"+noeudCourant)
                    var ns = [].concat(graphe.ListeNoeudAdjacents1());
                    console.log("voisins"+ns);
                    console.log("noeuds a visiter"+noeudsAVisiter);
                    //alert("suivant:___")

                    //alert("adjecent"+ns);

                    // On ajoute les voisins non encore visités
                    ns.forEach(n => {noeudsNonVisites.forEach(
                        function(e,i){
                                e.forEach(function(c,j){
                    
                            if ((c.ligne == n.ligne) && (c.colonne == n.colonne)){

                                noeudsNonVisites =  noeudsNonVisites.map(function(w){
                                    return w.filter(function(x){
                                        return (!(x.ligne == n.ligne && x.colonne == n.colonne));
                                    });
                                });

                        //alert(noeudsNonVisites);
                        //alert("__graphe__"+graphe.tuiles);
                                n.precurseur = noeudCourant;
                                n.distanceDuDepart = noeudCourant.distanceDuDepart + graphe.Cout(noeudCourant, n);
                                noeudsAVisiter.push(n);

                    }

                });
            });             
            


                            
                        
                    });
                }
            }
        
    }

// Algorithme de Bellman-Ford
    CheminsManager
    .prototype
    .BellmanFord =   function(graphe){
        
    
        // Méthode de résolution
        
            // Initialisation
            var distanceChangee = true;
            var i = 0;
            var listeArcs = graphe.ListeArcs();
            
            // Boucle principale
            var nbBoucleMax = graphe.NombreNoeuds() - 1;
            while (i < nbBoucleMax && distanceChangee) {
                distanceChangee = false;
                listeArcs.forEach( function(arcs,x){
                    arcs.forEach(function(arc,y){

                        if (arc.source.distanceDuDepart + arc.cout < arc.cible.distanceDuDepart) {
                            // On a trouvé un chemin plus court
                            //graphe.tuiles[arc.cible.ligne][arc.cible.colonne].distanceDuDepart = arc.source.distanceDuDepart + arc.cout;
                            //graphe.tuiles[arc.cible.ligne][arc.cible.colonne].precurseur = arc.source;
                            //console.log('++'+graphe.tuiles[arc.cible.ligne][arc.cible.colonne].precurseur);

                            arc.cible.distanceDuDepart = arc.source.distanceDuDepart + arc.cout;
                            arc.cible.precurseur = arc.source;
                            distanceChangee = true;
                            //console.log(graphe.tuiles[arc.cible.ligne][arc.cible.colonne].precurseur);
                        }

                    });

                       
                
                i = x+1;

                } ); 
                    
            }
            
            // Test si boucle négative
            listeArcs.forEach(function(arcs){
                arcs.forEach(function(arc,y){

                    if (arc.source.distanceDuDepart + arc.cout < arc.cible.distanceDuDepart) {
                        console.log("Boucle négative - pas de chemin le plus court");
                    }
                });

            }) ;
                
            
        
    }
    


function Application (){
    this.cheminsManager = null;
    this.algo = null;
    // Programme main
    //System.out.println("Recherche de chemins");
    
    }
    
Application
.prototype
.Lancer = function(cartez) {
    this.algo = cartez;
    console.log(cartez);
    // Cas 1ère carte
    this.cheminsManager = new CheminsManager(cartez);
    this.cheminsManager.Carte(cartez, 9, 0, 1, 9);
    this.LancerAlgorithmes(this.cheminsManager);      
            
    }
        
        // Lancement de tous les algorithmes à la suite
Application
.prototype
.LancerAlgorithmes = function(cheminM) {
    return this.LancerAlgorithme(this.algo, cheminM);
    
    }
        
        // Lancement d'un algorithme d'après son nom et affichage du temps
Application
.prototype
.LancerAlgorithme = function(nom,cheminsM) {
    // Initialisation
    algo = null;
            
            // Création de l'algorithme
            switch(nom) {
                case "Profondeur" :
                    cheminsM.RechercheEnProfondeur(cheminsM); 
                    return cheminsM.ReconstruireChemin(cheminsM);                   
                    break;
                case "Largeur" : 
                cheminsM.RechercheEnLargeur(cheminsM); 
                return cheminsM.ReconstruireChemin(cheminsM); 
                    break;
                case "Bellman-Ford" :
                    cheminsM.BellmanFord(cheminsM); 
                    return cheminsM.ReconstruireChemin(cheminsM); 
                    break;
                
            }
    //cheminsM.RechercheEnProfondeur(cheminsM);
    //alert("chemin"+cheminsM.ReconstruireChemin(cheminsM));

    //return cheminsM.ReconstruireChemin(cheminsM);
            
    }
        
        
        


