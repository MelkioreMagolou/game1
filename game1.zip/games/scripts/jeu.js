//var cheminsManager = new CheminsManager(levels);
var app = new Application(levels);

var balls = [];
var playfieldWidth, playfieldHeight;
var gameRefresh;
var ballSize;
var curLevel;
var bricks = []; 
var racket;
var bInit;
var algo = [];

var cheminfinale = [];
var cheminBricks = [];
var t = [];

		

$(document).ready(init);

function init()
{
    curLevel = 0;
    playfieldWidth = $('.playfield').width();
    playfieldHeight = $('.playfield').height();
	algo = ['Profondeur','Largeur','Bellman-Ford'];

	cheminfinale = new Array(algo.length);
	cheminBricks = new Array(algo.length);

	drawPlayfield();
    drawBalls();
	bInit = {l: $('.brick').width()/2, t: $('.brick').height()/2};
	gameRefresh = setInterval(drawBalls, 10);

	/*app.Lancer('Bellman-Ford');
	brickChemin();
	console.log("le chemin trouvé est :"+app.cheminsManager.cheminfin);

	app.Lancer('Largeur');
	brickChemin();
	console.log("le chemin trouvé est :"+app.cheminsManager.cheminfin);*/
	algosRun(algo);

	


	alert("Parcours de chemin intelligent");
	//alert(cheminf)
}

function drawPlayfield()
{
	levels[curLevel].forEach(function (e, i)
                             {
								  var line = $('<div class="brickLine"></div>');
			          				  e.forEach (function (f, j)
			                                       {
			                                         bricks.push ({
			                                                   		id: i + '-' + j, 
			                                      		    	 	top: i * 58,										     
			                                      		     		left: j * 62
			                                                     }) ;
			                                         line.append('<div class="brick ' + f + 'Brick" data-id="' + i + '-' + j + '"></div>');
			   						   });
			    			         $('.playfield').prepend(line);
					         }
 				      );
	bricks.forEach(function (e, i)
					  {
					     $('.brick[data-id="' + e.id + '"]')
		                          .animate(
								{
								   top: e.top + 'px'
								},
								500
							     );
						}
					);
	bricks.forEach(function (e, i)
					  {
						$('.brick[data-id="' + e.id + '"]')
					          .animate(
								{
								    left: e.left + 'px'
								},
								1000,
								function ()
								{
								   	if (i == bricks.length - 1)
								    {
			                           	addBall();
									}
							     });
				   });
}

function initBall()
{
	for (i=0; i < 3 ; i++){
		if( balls.length < 10)
			{
			$('.playfield').prepend('<div class="ball" data-id="' + balls.length + '"></div>');
	//ballSize = $('.ball:first').width();
			balls.push 	(
				{
					/*id: balls.length, 
					left: Math.random() * (playfieldWidth - ballSize), 
					top: Math.random() * (playfieldHeight - ballSize), 
					hSpeed: 2, 
					vSpeed: 2*/
					id: balls.length,
					left: cheminBricks[0][0].left + bInit.l/2, 
					top: cheminBricks[0][0].top + bInit.t/2, 
					hSpeed: 2, 
					vSpeed: 2,
					s : {i:0,j:0}

				}
			);
	}
		


	

				//t = cheminBricks.splice(0,1);
}
}

function algosRun(algo){
	for(var i = 0; i < algo.length; i++){
		app.Lancer(algo[i]);
		brickChemin(i);
	}
}

function drawBalls()
{

	balls.forEach (function (e)
            {

 	 	       forMoveball(e);
	   });
	   
}

function arretCourse(ef){
	var fin = cheminBricks[0][cheminBricks[0].length-1];
	id = ef.s.i+"-"+ef.s.j
	if(fin.id == id){
		//$('.ball[data-id="' + Number(id) + '"]').remove();
		clearInterval(gameRefresh);
		gameRefresh = undefined;
		


	}
}

function marquerchemin(b){
	

}


function brickChemin(y){
	cheminfinale[y] = app.cheminsManager.cheminfin.split("-");
	var cheminBrick = []
	var tab =[];
	cheminfinale[y].forEach(
		function(e){
			var s = e.split(';');
			var ss = [Number(s[0][1]), Number(s[1])];
			tab.push(ss);

	});
	tab.forEach(function(c){
		var id = c[0]+"-"+c[1];
		bricks.forEach(function(bc){
		if (id == bc.id){
			cheminBrick.push(bc);
		}
	});
	});
	cheminBricks[y]=cheminBrick;
}

function addBall(){
	initBall();
	balls
		.forEach 	(
			function (e)
                {
					$('.ball[data-id="' + e.id + '"]')
   					.css 	(
					{
						left: e.left + 'px',
						top: e.top + 'px'
					}
				);
                   			
		   				}
		   			);
	
}

function forMoveball(b){
	//c pour case et b pour ball

	cheminBricks[b.id].forEach(function(c){
		
		step(c,b);
		arretCourse(b);
	})
}

function step(c,b){
	var tab = c.id.split('-');
	var top1;
	var left1;
	tab = [Number(tab[0]), Number(tab[1])];
	/*if ((tab[0]==b.s.i) && (tab[1]==b.s.j)){     
		
	 }*/
	 

	 if(tab[0] == b.s.i){
		if(tab[1] > b.s.j){
			el = $('.brick[data-id="' + c.id + '"]').position();
			left1 = el.left + bInit.l/2;
			$('.ball[data-id="' + b.id + '"]')
				. animate(
					{
						left: left1 + 'px',
						
					},
					500
					 
				
					);
					b.s.j = tab[1];

				}
				else{

					el = $('.brick[data-id="' + c.id + '"]').position();
					left1 = el.left + bInit.l/2;

						$('.ball[data-id="' + b.id + '"]')
						. animate(
							{
								left: left1 + 'px',
								
							},
							500
							 
						);
						
							
		
		
						
						b.s.j = tab[1];
		
		
				}
				

		}

		


		if(tab[1] == b.s.j){
			if(tab[0] > b.s.i){
				el = $('.brick[data-id="' + c.id + '"]').position();
				top1 = el.top + bInit.t/2;

					$('.ball[data-id="' + b.id + '"]')
						. animate(
							{
								top: top1 + 'px',
								
							},
							500
							 
						);
	
					b.s.i = tab[0];
	
	
			}
	
			else{
	
				el = $('.brick[data-id="' + c.id + '"]').position();
				top1 = el.top + bInit.t/2;

					$('.ball[data-id="' + b.id + '"]')
						. animate(
							{
								top: top1 + 'px',
								
							},
							500
							 
						);
						

					}
	
					b.s.i = tab[0];
		}
	
	
	}

	